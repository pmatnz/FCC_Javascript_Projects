//**********************************************DATABASE IMPORTING*************************************************
// MUST ADD MODULE TO THE SCRIPT TAG IN THE HTML!!!!!

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js"; // importing DB link
//prettier-ignore
import {getDatabase, ref , push, onValue, remove} from "https://www.gstatic.com/firebasejs/9.15.0/firebase-database.js"

const appSettings = {
	databaseURL:
		"https://champions-d493c-default-rtdb.asia-southeast1.firebasedatabase.app/", // my personal DB link
};

const app = initializeApp(appSettings);
const database = getDatabase(app);
const endorsements = ref(database, "Endorsments");

//*********DOM BUTTONS***********/
const endorseInput = document.getElementById("endorse-text");
const endorseButton = document.getElementById("endorse-button");
const box1 = document.getElementById("box1");

//******Keeping DB updated in realtime onValue Firebase Function*******/

onValue(endorsements, function (snapshot) {
	let endormentsArray = Object.entries(snapshot.val());
	console.log(endormentsArray);
});

endorseButton.addEventListener("click", function () {
	let userInput = endorseInput.value;
	push(endorsements, userInput);
});
